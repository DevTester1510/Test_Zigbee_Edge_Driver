local version = {
  rpc = rpc_version(),
  api = 9,
}

return version
